from turtle import heading
import streamlit as st
import pandas as pd
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import datetime as dt
import numpy as np
import altair as alt
import plotly_express as px
import plotly.graph_objs as go
#import plost
list =[" ","Adani Power","Bajaj-Auto","Asian Paints","Axis Bank","HCL Tech","Hindustan Unilever","HDB","Infosys","Bharat Petroleum","JSW Energy","ITC","Kotak Bank","Larsen and Toubro","Nestle India","ONGC","Power Grid","Reliance","State Bank Of India","Tata Motors","Tata Steel","TCS","Tech Mahindra","Trident","UltraTech","Wipro","IBN (ICICI)"]

st.markdown("<h1 style='text-align:center;margin-top:-4rem; color: white;'>Stock Predictor</h1>", unsafe_allow_html=True)
nav = st.sidebar.radio("Navigation",["Home","Prediction","About"])

if nav=="Home":
    st.image("images/jeremy-bezanger-9opiHRPIvR0-unsplash.jpg")

if nav=="Prediction":
    st.write("<h2 style='color:yellow;'>Select a company :</h2>",unsafe_allow_html=True)
    result = st.selectbox(" ",list)

    if (result == "Adani Power"):
         st.image("images/adani.jpg",width=450)

         url = "https://app.powerbi.com/groups/me/reports/b26070ca-6510-4ade-9bc8-580ad475a5c2/ReportSection"
         
         df=pd.read_csv('new_data_adanipower.csv')
         plot=px.line(x='Date',y='Close',data_frame=df,title=("Adani Power STOCK PREDICTION"))
          #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
         plot.add_trace(go.Scatter(
              x=df['Date'],
              y=df['Prediction'],
              name="Prediction"       # this sets its legend entry
              ))
         plot.update_layout(
              font_family="Times New Roman",
              font_color="blue",
              title_font_family="Times New Roman",
              title_font_color="red",
              legend_title_font_color="green"
         )
         plot.show()


         st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

         st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Adani Power Ltd, is an Indian power and energy company, subsidiary of Indian conglomerate Adani Group with head office at Khodiyar in Ahmedabad, Gujarat. It is a private thermal power producer, with capacity of 12,450 MW. It also operates a mega solar plant of 40 MW at Naliya, Bitta, Kutch, Gujarat. It is India's first company that synchronises the supercritical technology.</p>"

         "<p style = 'color : white ;margin-top:2.5rem; font-size : 1.3rem ;ffont-family: 'Crimson Text', serif;'> Adani Godda Power is implementing a 1,600 MW plant at Jharkhand. The company has signed long term power purchase agreements of about 9,153 MW with government of Gujarat, Maharashtra, Haryana, Rajasthan, Karnataka, and Punjab </p>",unsafe_allow_html=True)

         st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

         st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•<b><u> Beating 3 Yr Revenue CAGR </u></b><br> Company's annual revenue growth of 12.56% outperformed its 3 year CAGR of 6.26%. (Source: Consolidated Financials)</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Employee & Interest Expense</u></b><br>Company has spent 14.78% of its operating revenues towards interest expenses and 1.7% towards employee cost in the year ending 31 Mar, 2022. (Source: Consolidated Financials)",unsafe_allow_html=True)
         
    elif(result == "Bajaj-Auto"):
         st.image("images/bajaj.png",width=450)

         url = "https://app.powerbi.com/groups/me/reports/ffe82355-7404-4725-b485-7511888acfReportSection"

         st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

         st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Bajaj Auto Limited  is an Indian multinational automotive manufacturing company based in Pune. It manufactures motorcycles, scooters and auto rickshaws. Bajaj Auto is a part of the Bajaj Group. It was founded by Jamnalal Bajaj (1889–1942) in Rajasthan in the 1940s.</p>"

         "<p style = 'color : white ;margin-top:2.5rem; font-size : 1.3rem ;font-family: 'Crimson Text', serif; '> Bajaj Auto is the world's third-largest manufacturer of motorcycles and the second-largest in India. It is the world's largest three-wheeler manufacturer. In December 2020, Bajaj Auto crossed a market capitalisation of ₹1 trillion (US$13 billion), making it the world's most valuable two-wheeler company.</p>",unsafe_allow_html=True)
         df=pd.read_csv('new_data_bajajauto.csv')
         #df1=pd.read_csv('train_bajajuto.csv')
         #df2=pd.read_csv('valid_bajajauto.csv')

         def date_convert(date_to_convert):
           return dt.datetime.strptime(date_to_convert, '%b %d, %Y').strftime('%d/%m/%Y')
         plt.gca().xaxis.set_major_formatter(mdates.DateFormatter("%d-%m-%Y"))
         plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=60))
         #df1['Date']=pd.to_datetime(df1['Date']).dt.strftime('%d-%m-%Y')
         list=df.columns.to_list()
         data=df[list]
         #x_dates=[dtpip.datetime.strptime("d",'%d-%m-%Y').date() for d in df.index.values].apply(date_convert)
         x_dates_1=df.Date[:199]
         x_dates_2=df.Date[199:]
         #st.line_chart(df.rename(columns=).set_index())
         
         date=df['Date']
         close=df['Close']
         #plot=px.line(x='Date',y='Close',data_frame=df)
         #plot=px.line(x='Date',y='Prediction',data_frame=df2)
         #plot.add_scatter(x=df['Date'], y=df['Close'], mode='lines')
         #plot.add_scatter(x='Date',y='Close',data_frame=df)
         #df1 = df.melt(id_vars=['Date']+list(df.keys()[5:]), var_name='AAPL')
         #px.line(df1, x='Date', y='value', color='AAPL' )
         #df1=df1.set_index('Date')
         
         plot=px.line(x='Date',y='Close',data_frame=df,title=("Bajaj Auto STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
         plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
         plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
         plot.show()
         
         
         #df2=df2.set_index('Date')
         #st.line_chart(req_val)
         #st.line_chart(df1)
         #st.line_chart(df2)
         

         
         #st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

         #plost.line_chart(df,'Date',"Close")

         st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u> New dividend policy – a positive</u></b><br>The company has linked the dividend pay out to level of cash reserves. Given the current level of reserve, dividend payment for FY23 and beyond may see a sharp rise.</p>"

         "<p style = 'color :white;font-size : 1.1remfont-family: 'Crimson Text', serif;'>•	<b><u>Healthy sales and product mix</u></b><br>The company is well-hedged from any slowdown in one particular segment, because of its sales in two-wheelers in the domestic rural and urban areas, sales of three-wheelers and exports. In FY 22, when exports were hurt due to shortage of containers, it was domestic saved the day. When domestic came under pressure due to partial lock downs, it was export which came to rescue."
         "<p style = 'color :white;font-size : 1.1remfont-family: 'Crimson Text', serif;'>•	<b><u>Healthy sales and product mix</u></b><br>The company is well-hedged from any slowdown in one particular segment, because of its sales in two-wheelers in the domestic rural and urban areas, sales of three-wheelers and exports. In FY 22, when exports were hurt due to shortage of containers, it was domestic saved the day. When domestic came under pressure due to partial lock downs, it was export which came to rescue."

         "<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•<b><u> Forward integration</u></b><br>A large majority of the domestic two-wheeler sales and three-wheeler sales of the company are financed by the group company, Bajaj finance. It cushions Bajaj Auto from any liquidity squeeze in financial system.</p>"

         "<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Zero Debt Burden</u></b><br>Company has no debt since last 5 years. (Source: Consolidated Financials)</p>",unsafe_allow_html=True)
        
    elif(result == "Asian Paints"):
        st.image("images/asianpaints.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/ab071a1c-68bd-4372-91bd-26dd749254ea/ReportSection"
        df=pd.read_csv('new_data_asian_paints.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Asian Paints STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()

        

        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)
        
        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Asian Paints Ltd is an Indian multinational paint company, headquartered in Mumbai, Maharashtra, India. The company is engaged in the business of manufacturing, selling and distribution of paints, coatings, products related to home décor, bath fittings and providing of related services. Asian Paints is India's largest and Asia's third largest paints corporation. Asian Paints is the holding company of Berger International. The company generated a revenue of ₹17,194.1 crores in the financial year 2019-20 and a profit of ₹2,654 crores. The company's manufacturing operations encompass 15 countries of the world including India, with considerable presence in the Indian subcontinent and the Middle East.</p> ",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u> Crude connection </u></b><br> Derivatives of crude oil being the major raw material, crude oil price hold the key to margins. Higher crude oil price create problems for the margin and hence bottom line</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 33.91% outperformed its 3 year CAGR of 14.67%. (Source: Consolidated Financials)"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Future-proofing solution</u></b><br>In the medium-to-long term, the home improvement segment, which includes kitchen and bathroom accessory business, would be one of the key drivers of overall sales growth and margin expansion",unsafe_allow_html=True)

    elif(result == "Axis Bank"):
        st.image("images/axisbank.png",width=450)

        url = "https://app.powerbi.com/groups/me/reports/6f39cc2d-95d7-4f73-9903-1a6757818f84/ReportSection"
        
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)
        df=pd.read_csv('new_data_axisbank (1).csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Axis Bank STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()


        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Axis Bank Limited, formerly known as UTI Bank (1993–2007), is an Indian banking and financial services company headquartered in Mumbai, Maharashtra. It sells financial services to large and mid-size companies, SMEs and retail businesses. </p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>As of 30 June 2016, 30.81% shares are owned by the promoters and the promoter group (United India Insurance Company Limited, Oriental Insurance Company Limited, National Insurance Company Limited, New India Assurance Company Ltd, GIC, LIC and UTI). The remaining 69.19% shares are owned by mutual funds, FIIs, banks, insurance companies, corporate bodies and individual investors.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u>First signs of credit off take improving</u></b><br> The retail part of loan book saw healthy growth, SME numbers have also turned better as they performed in last quarter If this growth continues without compromising on quality of borrowers, it is long term positive for valuations as quality of loan book is one of the biggest factor which determines the valuation which bank gets on the street.</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Loan Book Growth - Beating 5 Yr CAGR</u></b><br>Axis Bank Ltd. reported a YoY increase of 14.18% in its advances, which is higher than its 5 yr CAGR of 10.02%. (Source: Consolidated Financials)</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Citi taken over..</u></b><br>The acquisition of Citi bank's India consumer business is likely to accretive as far as return on asset (ROA) is concerned. The real challenge would be integration, both on the employee and business front.",unsafe_allow_html=True)


    elif(result == "HCL Tech"):

        st.image("images/download (1).png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/1f73832a-9f7e-4e4f-9898-bed4fbf5f00f/ReportSection"

        #st.image("images/hcl stock.png",width=800)
        df=pd.read_csv('new_data_hcl.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("HCL Tech STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()

        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>HCL Technologies (Hindustan Computers Limited) is an Indian multinational information technology (IT) services and consulting company headquartered in Noida. It is a subsidiary of HCL Enterprise. Originally a research and development division of HCL, it emerged as an independent company in 1991 when HCL entered into the software services business. The company has offices in 50 countries and over 187,000 employees.</p>" 

        "<p style = 'color : white ;margin-top:2.5rem; font-size : 1.3rem ;font-family: 'Crimson Text', serif; '> HCL Technologies is on the Forbes Global 2000 list. It is among the top 20 largest publicly traded companies in India with a market capitalisation of $50 billion as of September 2021. As of July 2020, the company, along with its subsidiaries, had a consolidated annual revenue of ₹71,265 crore (US$10 billion).</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•  <b><u>Intraday fact check</u></b><br> In the last 17 years, only 2.01 % trading sessions saw intraday declines higher than 5 % .</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Employee & Interest Expense</u></b><br>Company has spent less than 1% of its operating revenues towards interest expenses and 53.86% towards employee cost in the year ending 31 Mar, 2022. (Source: Consolidated Financials)"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Sell Signal: Bears might roar again</u></b><br>Weekly stochastic crossover appeared on week ending Sep 02, 2022. Average price decline of -4.4% within 7 weeks of this signal in last 10 years."

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Stock Returns vs Nifty 100</u></b><br>Stock gave a 3 year return of 66.82% as compared to Nifty 100 which gave a return of 62.37%. (as of last trading session)",unsafe_allow_html=True)
    elif(result == "Hindustan Unilever"):
        st.image("images/hinduunilvr.png",width=450)

        url = "https://app.powerbi.com/groups/me/reports/06095838-5549-4d57-8c52-9811291a07e9/ReportSection"
        #st.image("images/hindustan uni stock.png",width=800)
        
        df=pd.read_csv('new_data_hindunilvr.csv')
        
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Hindustan Unilever STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
         

        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Hindustan Unilever Limited (HUL) is a consumer goods company headquartered in Mumbai, India. It is a subsidiary of Unilever, a British company. Its products include foods, beverages, cleaning agents, personal care products, water purifiers and other fast-moving consumer goods.</p>"

        "<p style = 'color : white ;margin-top:2.5rem; font-size : 1.3rem ;font-family: 'Crimson Text', serif;'> HUL was established in 1931 as Hindustan Vanaspati Manufacturing Co. and following a merger of constituent groups in 1956, it was renamed Hindustan Lever Limited. The company was renamed in June 2007 as Hindustan Unilever Limited. As of 2019, Hindustan Unilever's portfolio had 44 product brands in 14 categories. The company has 18,000 employees and clocked sales of ₹34,619 crores in FY2017–18. </p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Agri inputs matrix<br> Palm oil and tea being agro-inputs, they tend to bring volatility in the gross margin of the company. At present, palm oil price are trending higher which might act as headwind in coming quarter.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Inflation - will it become a headache ?</u></b><br>Rising oil prices may soon hit disposable income of consumers to the level where discretionary spending starts getting hit, how long it would take to show its impact on sales of FMCG company need to be watched."

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Fresh challenges from platforms companies ?</u></b><br>The skincare and cosmetic portfolio may face a fresh round of challenge from consumer tech platform companies like Nyakaa , who are not only giving higher discount as compared to traditional channels of distribution but also introduce other foreign brands which adds to competition to this segment."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Less aggressive price hikes - gain in market share ?</u></b><br>In recent past, company took less aggressive price hike as compared to its competitor in tea and soap segment. But given fresh round of spike in commodity prices and logistic inflation hitting economy, it needs to be watch till when company is able to protect its margin and also the market share.",unsafe_allow_html=True)


    elif(result == "HDB"):
        st.image("images/HDB.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/002508ef-7c1a-4eb4-8eed-3c0d8f6cb1f6/ReportSection"
        #st.image("images/hdb stock.png",width=800)
        df=pd.read_csv('new_data_hdbc.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("HDBC Bank STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>HDFC Bank Limited is an Indian banking and financial services company headquartered in Mumbai. It is India's largest private sector bank by assets and world's 10th largest bank by market capitalisation as of April 2021. It is the third largest company by market capitalisation of $122.50 billion on the Indian stock exchanges.[13] It is also the fifteenth largest employer in India with nearly 150,000 employees</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       

    elif(result == "Infosys"):
        st.image("images/INFY.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/734fcbaf-05bd-4547-b722-c9158d691f53/ReportSection"
        #st.image("images/infosys stock.png",width=800)
        df=pd.read_csv('new_data_infy.csv')
        
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Infosys STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
        
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)
        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Infosys Limited is an Indian multinational information technology company that provides business consulting, information technology and outsourcing services. The company was founded in Pune and is headquartered in Bangalore. Infosys is the second-largest Indian IT company after Tata Consultancy Services by 2020 revenue figures and the 602nd largest public company in the world, according to the Forbes Global 2000 ranking.On 24 August 2021, Infosys became the fourth Indian company to cross $100 billion in market capitalization.</p>"
        "<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family:'Crimson Text', serif;'>In India, shares of Infosys are listed on the BSE where it is a part of the BSE SENSEX and the NSE where it is a NIFTY 50 Constituent. Its shares are listed by way of American depositary receipts (ADRs) at the New York Stock Exchange.Over a period of time, the shareholding of its promoters has gradually reduced, starting from June 1993 when its shares were first listed. The promoters' holdings reduced further when Infosys became the first Indian-registered company to list Employees Stock Options Schemes and ADRs on NASDAQ on 11 March 1999. As of 29 July 2021, the promoter holding was 12.95%, foreign institutional investors (FIIs) hold 33.39%, and domestic institutional investors (DIIs) hold 21.98%.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u>Stock Returns vs Nifty 100</u></b><br>Stock gave a 3 year return of 73.2% as compared to Nifty 100 which gave a return of 62.82%. (as of last trading session)</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •<b><u> Employee & Interest Expense</b></u><br>Company has spent less than 1% of its operating revenues towards interest expenses and 52.6% towards employee cost in the year ending 31 Mar, 2022. (Source: Consolidated Financials)</p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •<b><u> Beating 3 Yr Revenue CAGR</b></u><br>Company's annual revenue growth of 20.71% outperformed its 3 year CAGR of 13.01%. (Source: Consolidated Financials)",unsafe_allow_html=True)




    elif(result == "Bharat Petroleum"):
        st.image("images/BPCL.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/f4f3e097-2ec1-41f8-b92c-63ec1818347d/ReportSection"
        df=pd.read_csv('new_data_bpcl.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("BPCL STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
                


        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family:'Crimson Text', serif;'>Bharat Petroleum Corporation Limited (BPCL) is an Indian government-owned oil and gas explorer and producer, headquartered in Mumbai. It operates three refineries in Bina, Kochi and Mumbai. BPCL is India's second-largest government-owned downstream oil corporation, whose operations are overseen by the Ministry of Petroleum and Natural Gas. It was ranked 309th on the 2020 Fortune list of the world's biggest corporations and 792nd on Forbes's 2021 Global 2000 list.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•  <b><u>Moving toward green means capital expenditure</u></b><br>Most of global OMC are taking steps to move toward green energy, BPCL will also be no different as it makes plans to move toward its target of becoming net zero emitter. However this means that capex would remain higher in coming years.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>PAT: Slipping to Red</u></b><br>Company has posted a loss of Rs 6147.94 cr in 30 Jun, 2022 quarter after 3 consecutive quarter of profits. (Source: Consolidated Financials)</p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Stock Returns vs Nifty 100</u></b><br>Stock gave a 3 year return of -14.45% as compared to Nifty 100 which gave a return of 62.82%. (as of last trading session)</p>",unsafe_allow_html=True)


    elif(result == "JSW Energy"):
        st.image("images/jsw.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/2b89582d-9f09-489f-8beb-6c033a1c8898/ReportSection"
        #st.image("images/jsw stock.png",width=800)
        df=pd.read_csv('new_data_jswenergy.csv')
        
        plot=px.line(x='Date',y='Close',data_frame=df,title=("JSW Energy STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>JSW Energy Limited (JSWEL) is a division of JSW Group in India.JSW Energy is in various areas of power: Generation, Transmission and Trading.JSW Energy has 5681 MW of operational generating capacity. In addition, it has power generation projects at an early stage under development with a proposed combined installed capacity of 8630 MW.</p>"
        "<p>The board of directors of Jaiprakash Power Ventures, a fully owned subsidiary of the Jaypee group, has approved the 100 per cent transfer of businesses of its operating power plants – the 300-MW Baspa-II hydroelectric plant (commissioned in 2003) and the 1,091-MW Karcham Wangtoo plant (commissioned in 2011), in Himachal Pradesh.JMD Sanjay Sagar heading JSW energy.operating from Mumbai corporate</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•  <b><u>Intraday fact check</u></b><br>In the last 12 years, only 3.66 % trading sessions saw intraday gains higher than 5 % .</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 22.01% outperformed its 3 year CAGR of -2.75%. (Source: Consolidated Financials)</p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Stock Returns vs Nifty 100</u></b><br>Stock gave a 3 year return of 450.0% as compared to Nifty 100 which gave a return of 62.82%. (as of last trading session)</p>",unsafe_allow_html=True)


    elif(result == "ITC"):
        st.image("images/ITC.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/970c3b42-5896-4d46-9b5d-a3314ad90215/ReportSection"
        #st.image("images/itc stock.png",width=800)
        df=pd.read_csv('new_data_itc.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("ITC STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>ITC Limited is an Indian conglomerate company headquartered in Kolkata. ITC has a diversified presence across industries such as cigarettes, FMCG, hotels, software, packaging, paperboards, specialty papers and agribusiness. The company has 13 businesses in 5 segments. It exports its products in 90 countries. Its products are available in 6 million retail outlets.</p>"
        "<p>Established in 1910 as the Imperial Tobacco Company of India Limited, the company was renamed as the India Tobacco Company Limited in 1970 and later to I.T.C. Limited in 1974. The company now stands renamed ITC Limited, where ITC today is no longer an acronym. As of 2019–20, ITC had an annual turnover of US$10.74 billion and a market capitalisation of US$35 billion. It employs 36,500 people at more than 60 locations across India.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•  <b><u>Intraday fact check</u></b><br>In the last 17 years, only 0.86 % trading sessions saw intraday declines higher than 5 % .</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>All Debts Paid-off</u></b><br>Company has become debt free for the first time since last 5 years. (Source: Consolidated Financilas).</p>"
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 20.42% outperformed its 3 year CAGR of 7.27%. (Source: Consolidated Financials)</p>"
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Buy Signal: Advantage Bulls !</u></b><br>Daily MACD crossover appeared on Sep 05, 2022. Average price gain of 3.14% within 10 days of this signal in last 10 years.</p>",
        unsafe_allow_html=True)

    elif(result == "Kotak Bank"):
        st.image("images/kotak.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/69f0b144-c8b2-4661-ae55-c73548600a20/ReportSection"
        #st.image("images/kotak stock.png",width=800)
        df=pd.read_csv('new_data_kotak.csv')
        
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Kotak Bank STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Kotak Mahindra Bank Limited is an Indian banking and financial services company headquartered in Mumbai, India.It offers banking products and financial services for corporate and retail customers in the areas of personal finance, investment banking, life insurance, and wealth management. It is India's third largest private sector bank by assets and by market capitalisation as of November 2021. As of February 2021, the bank has 1600 branches and 2519 ATMs..</p>"
        "<p>In 2017, Kotak Mahindra Bank acquired Old Mutual's 26% stake in Kotak Mahindra Old Mutual Life Insurance for ₹1,292 crore (US$198.4 million), making the life insurance company its wholly-owned subsidiary.In 2021, the bank acquired a 9.99% stake in Ferbine, an entity promoted by Tata Group, to operate a Pan-India umbrella entity for retail payment systems, similar to National Payments Corporation of India.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•  <b><u>Loan Book Growth - Beating 5 Yr CAGR</u></b><br>Kotak Mahindra Bank Ltd. reported a YoY increase of 20.73% in its advances, which is higher than its 5 yr CAGR of 8.13%. (Source: Consolidated Financials).</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Profit Per Branch - Uptrend</u></b><br>Net profit per branch has been continuously increasing over the last 3 years with a growth of 16.13% last year. (Source: Standalone Financials)</p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;;'> •  <b><u>Sell Signal: Bearish trend in offing</u></b><br>5 day moving crossover appeared today. Average price decline of -2.29% within 7 days of this signal in last 5 years.</p>", unsafe_allow_html=True)

    elif(result == "Larsen and Toubro"):
        st.image("images/LT.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/cea1437c-f439-4d83-b737-639fc4f8c7f9/ReportSection"
        #st.image("images/LT stock.png",width=800)
        df=pd.read_csv('new_data_LT.csv')
        
        plot=px.line(x='Date',y='Close',data_frame=df,title=("L&T STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;;'>Larsen & Toubro Ltd, commonly known as L&T, is an Indian multinational conglomerate company, with business interests in engineering, construction, manufacturing, technology, information technology and financial services, headquartered in Mumbai. The company is counted among world's top five construction companies. It was founded by Henning Holck-Larsen and Søren Kristian Toubro, who were two Danish engineers taking refuge in India.As of 2020, L&T Group comprises 118 subsidiaries, 6 associates, 25 joint-venture and 35 joint operations companies, operating across basic and heavy engineering, construction, realty, manufacturing of capital goods, information technology, and financial services.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u> Higher oil price and Middle East</u></b><br>Given recent increase in global oil-price scenario, countries in the Middle East who had been slowing their investments in infrastructure will get once again push it up. If they do, it would become a tailwind for its order book.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Monetisation of non-core assets</u></b><br>Monetisation of some of the power and metro rail where capital is locked should help in improving the operational and financial matrix.</p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Pre-covid blues</u></b><br>The slowdown for the company had existed even before the Covid-19 crisis began. There is hardly any capex taking place from the private sector. Only government spending had been the source of orders.</p>", unsafe_allow_html=True)

    elif(result == "Nestle India"):
        st.image("images/nestle.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/1c91f1cc-9c9a-47d8-b4b4-e86be1efb5f4/ReportSection"
        #st.image("images/nestle stock.png",width=800)
        st.write("## For Analysis Of This Stock [Click Here](%s)" % url)
        df=pd.read_csv('new_data_nestle.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Nestle India STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()


        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Nestlé India Limited is the Indian subsidiary of Nestlé which is a Swiss multinational company. The company is headquartered in Gurgaon, Haryana. The company's products include food, beverages, chocolate, and confectioneries.The company was incorporated on 28 March 1959 and was promoted by Nestle Alimentana S.A. via a subsidiary, Nestle Holdings Ltd.[8][9] As of 2020, the parent company Nestlé owns 62.76% of Nestlé India.[6] The company has 9 production facilities in various locations across India.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u>Intraday fact check</u></b><br>In the last 12 years, only 0.66 % trading sessions saw intraday gains higher than 5 % .</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Contingent Liabilities Coverage</u></b><br>Company has sufficient cash reserves to pay off its contingent liabilities. (Source: Standalone Financials)</p>."

        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Sell Signal: Bears back on track</u></b><br>20 day moving crossover appeared on Sep 05, 2022. Average price decline of -1.73% within 7 days of this signal in last 5 years.</p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Employee & Interest Expense</u></b><br>Company has spent 1.37% of its operating revenues towards interest expenses and 10.34% towards employee cost in the year ending 31 Dec, 2021. (Source: Standalone Financials).</p>", unsafe_allow_html=True)

    elif(result == "ONGC"):
        st.image("images/ongc.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/8d96be79-83e7-4364-afc0-5c772413f3d8/ReportSection"
        #st.image("images/ongc stock.png",width=800)
        df=pd.read_csv('new_data_ongc.csv')
        
        plot=px.line(x='Date',y='Close',data_frame=df,title=("ONGC STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>The Oil and Natural Gas Corporation (ONGC) is an Indian oil and gas explorer and producer, headquartered in New Delhi. ONGC was founded on 14 August 1956 by the Government of India. It is a public sector undertaking whose operations are overseen by the Ministry of Petroleum and Natural Gas. It is the largest government-owned-oil and gas exploration and production corporation in the country, and produces around 70% of India's crude oil (equivalent to around 57% of the country's total demand) and around 84% of its natural gas. In November 2010, the Government of India conferred the Maharatna status to ONGC.In a survey by the Government of India for fiscal year 2019–20, it was ranked as the largest profit making Public Sector Undertaking (PSU) in India. It is ranked 25th among the Top 250 Global Energy Companies by Platts.</p>"
         "<p>The equity shares of ONGC are listed on the Bombay Stock Exchange, where it is a constituent of the BSE SENSEX index, and the National Stock Exchange of India,where it is a constituent of the S&P CNX Nifty.As on 31 March 2013, Government of India held around 69% equity shares in ONGC. Over 480,000 individual shareholders hold approx. 1.65% of its shares. Life Insurance Corporation of India is the largest non-promoter shareholder in the company with 7.75% shareholding.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u>Intraday fact check</u></b><br>In the last 17 years, only 1.46 % trading sessions saw intraday gains higher than 5 % .</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>ROE Outperforming 5 Year Average</u></b><br>Company delivered ROE of 17.54% in year ending 31 Mar, 2022 outperforming its 5 year avg. of 11.3%. (Source: Consolidated Financials)</p>."

        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 59.17% outperformed its 3 year CAGR of 5.05%. (Source: Consolidated Financials).</p>.",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u>Intraday fact check</u></b><br>In the last 12 years, only 0.66 % trading sessions saw intraday gains higher than 5 % .</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Contingent Liabilities Coverage</u></b><br>Company has sufficient cash reserves to pay off its contingent liabilities. (Source: Standalone Financials)</p>."

        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Sell Signal: Bears back on track</u></b><br>20 day moving crossover appeared on Sep 05, 2022. Average price decline of -1.73% within 7 days of this signal in last 5 years.</p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Employee & Interest Expense</u></b><br>Company has spent 1.37% of its operating revenues towards interest expenses and 10.34% towards employee cost in the year ending 31 Dec, 2021. (Source: Standalone Financials).</p>", unsafe_allow_html=True)

    elif(result == "Power Grid"):
        st.image("images/power grid.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/8ad97dd2-2429-4805-b11c-b3cb8edb17a0/ReportSection"
        #st.image("images/power grid stock.png",width=800)
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)
        
        df=pd.read_csv('new_data_powergrid.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Power Grid STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Power Grid Corporation of India Limited is an Indian public sector undertaking engaged mainly in transmission of bulk power across different states of India. It is under the jurisdiction of Ministry of Power, Government of India and headquartered in Gurugram. Power Grid transmits about 50% of the total power generated in India on its transmission network. It is also certified for PAS 99.</p>"
        "<p>Power Grid is listed on both the BSE and the NSE. As of 30 September 2010, there were 792,096 equity shareholders holders in Power Grid. Initially, Power Grid managed transmission assets owned by NTPC, NHPC Limited and NEEPCO Limited. In January 1993, the Power Transmission Systems Act transferred ownership of the three power companies to Power Grid. All employees of the three companies subsequently became Power Grid employees.</p>",unsafe_allow_html=True)

        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• <b><u>Intraday fact check</u></b><br>In the last 15 years, only 1.14 % trading sessions saw intraday declines higher than 5 % .</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>ROE Outperforming 5 Year Average</u></b><br>Company delivered ROE of 22.06% in year ending 31 Mar, 2022 outperforming its 5 year avg. of 17.93%. (Source: Consolidated Financials)</p>."

        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Employee & Interest Expense</u></b><br>Company has spent 19.31% of its operating revenues towards interest expenses and 5.39% towards employee cost in the year ending 31 Mar, 2022. (Source: Consolidated Financials)/p>."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •  <b><u>Sell Signal: Bears back on track</u></b><br>20 day moving crossover appeared today. Average price decline of -2.16% within 7 days of this signal in last 5 years.</p>", unsafe_allow_html=True)

    elif(result == "Reliance"):
        st.image("images/reliance.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/82c1102e-c856-4be1-81f6-e3e633e8e133/ReportSection"
        #st.image("images/reliance stock.png",width=800)
        df=pd.read_csv('new_data_reliance.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Reliance STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Reliance Industries Limited is an Indian multinational conglomerate company, headquartered in Mumbai. It has diverse businesses including energy, petrochemicals, natural gas, retail, telecommunications, mass media, and textiles. Reliance is one of the most profitable companies in India, the largest publicly traded company in India by market capitalization, and the largest company in India as measured by revenue. It is also the tenth largest employer in India with over 236,000 employees. RIL has a market capitalization of US$243 billion as of March 31, 2022</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
        st.write("<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Entry into green energy - Another round of Capex ?</u></b><br>Another round of capex may get restarted as the company enters into green energy business. While the return on new investments will take time to come, in medium term it may help company improve its ESG score, which matter a lot to global fund houses hence to overall valuations. The recent acquisition in clean energy space, indicates that company may be more aggressive than what was being expected by street."

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Will ARPU rise on sustained basis ?</u></b><br>In order to gain and retain its market share, RIL had adopted an aggressive pricing strategy for Jio. However, in the last few months, there has been an increase in tariff across the telecom industry. Will this price hike lead to a gradual increase in its ARPU (Average Revenue Per User) needs to be watched. If that was to happen it will help in improving net margins of the telecom business."
        
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Oil to chemical segment - it matters a lot</u></b><br>With the deal with Saudi Aramco being called off, will RIL is able to get another partner for its old economy business which are still the major contributor to its overall top and bottom line is an important factor to watch for. Also movement in crude oil price and refining margins remains a key factor in near term.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Beating 3 Yr Revenue CAGR </u></b><br>Company's annual revenue growth of 47.94% outperformed its 3 year CAGR of 7.29%. (Source: Consolidated Financials)</p>",unsafe_allow_html=True)


    elif(result == "State Bank Of India"):
        st.image("images/SBI.png",width=450) 

        url = "https://app.powerbi.com/groups/me/reports/51cd88c9-b7d8-4c51-a536-82c355021aa5/ReportSection"

        #st.image("images/sbi stock.png",width=800)
        df=pd.read_csv('new_data_sbin.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("State Bank of India STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()

        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>State Bank of India (SBI) is an Indian multinational public sector bank and financial services statutory body headquartered in Mumbai, Maharashtra. SBI is the 43rd largest bank in the world and ranked 221st in the Fortune Global 500 list of the world's biggest corporations of 2020, being the only Indian bank on the list. It is a public sector bank and the largest bank in India with a 23% market share by assets and a 25% share of the total loan and deposits market. It is also the fifth largest employer in India with nearly 250,000 employees.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u><b><u>Big chunk- housing finance</u></b><br> Home loan, constitutes 23.34 % of Bank’s domestic advances. The total housing advances at the end of Q4 FY 22 stood at Rs 5,61,651 crore, making SBI one of the largest housing financers in India. Home loan witnessed both YoY and QoQ growth in Q4, FY 22."

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;;'> •	<b><u>Q4, FY 22 - Nothing extraordinary, how ever</u></b><br>There was up tick in corporate loans segment, does it means that capex cycle is finally inching up a bit ? No major asset quality challenge as of now. The net interest margin (NIM) went in stand still mode in Q4, stood at 3.40 percent, though on YOY basis better by 29 basis point.</p>"
        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>• Watch out factor - Digital growth</u></b><br>While bank had been taking steps to increase its digital footprints with YONO, 36 percent of retail asset accounts and 63 percent of savings accounts opened through YONO in FY22. Given the challenges which fintech companies are bringing to retail lending space, how nimble footed the is bank with its digital initiatives should be watched carefully. How much of its new retail business comes from digital channels is factor to watch for. It will an impact on growth matrix of retail portfolio in long term.</p>",unsafe_allow_html=True)

    elif(result == "Tata Motors"):
        st.image("images/tata motors.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/e13c544d-19d2-431c-a915-2537bd0f92a2/ReportSection"
        #st.image("images/tata motors stock.png",width=800)
        df=pd.read_csv('new_data_tatamotors.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Tata Motors STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'> Tata Motors Limited is an Indian multinational automotive manufacturing company, headquartered in Mumbai, India, which is part of the Tata Group. The company produces passenger cars, trucks, vans, coaches, buses, luxury cars, sports cars, construction equipment.</p>"

        "<p style = 'color : white ;margin-top:2.5rem; font-size : 1.3rem ;font-family: 'Crimson Text', serif;'> Formerly known as Tata Engineering and Locomotive Company (TELCO), the company was founded in 1945 as a manufacturer of locomotives. The company manufactured its first commercial vehicle in 1954 in a collaboration with Daimler-Benz AG, which ended in 1969. Tata Motors entered the passenger vehicle market in 1988 with the launch of the TataMobile followed by the Tata Sierra in 1991, becoming the first Indian manufacturer to achieve the capability of developing a competitive indigenous automobile.[5] In 1998, Tata launched the first fully indigenous Indian passenger car, the Indica, and in 2008 launched the Tata Nano, the world's most affordable car. Tata Motors acquired the South Korean truck manufacturer Daewoo Commercial Vehicles Company in 2004. Tata Motors has been the parent company of Jaguar Land Rover since the company established it for the acquisition of Jaguar Cars and Land Rover from Ford in 2008. </p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Inorganic capacity addition</u></b><br> The takeover of Ford's India plants would add to the capacity dramatically, if used for ramping up EV's production than ROC would improve in the PV segment in coming years."

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>EV - With money in pocket. time to focus on challenges</u></b><br>The company has been able to raise funds in its passenger EV business unit. While there has been an uptick in monthly EV sales but the base is too small for a meaningful conclusion. The factor to watch for is whether company is able to build on the first mover advantage given its large network. Also watch out for competition from other players.</p>"
         "<p style = 'color :white;font-size : 1.1rem;font-family:Hind;'> •	Target zero debt - Some more action required</u></b><br>The company plans to have zero debt by 2024. This would entail, reducing capex and selling some of the non-core assets. For another round of re-rating some more tangible needs to come on debt reduction.</p>",unsafe_allow_html=True)

    elif(result == "Tata Steel"):
        st.image("images/tata steel.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/1afa4811-a02e-4710-9874-040d8fe96335/ReportSection"
        #st.image("images/tata steel stock.png",width=800)
        df=pd.read_csv('new_data_tatasteel.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Tata Steel STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'> Tata Steel Limited is an Indian multinational steel-making company, based in Jamshedpur, Jharkhand and headquartered in Mumbai, Maharashtra. It is a part of the Tata Group.</p>"

        "<p style = 'color : white ;margin-top:2.5rem; font-size : 1.3rem ;font-family: 'Crimson Text', serif; '> Formerly known as Tata Iron and Steel Company Limited (TISCO), Tata Steel is among the top steel producing companies in the world with an annual crude steel capacity of 34 million tons. It is one of the world's most geographically diversified steel producers, with operations and commercial presence across the world. The group (excluding SEA operations) recorded a consolidated turnover of US$19.7 billion in the financial year ending 31 March 2020. It is the second largest steel company in India (measured by domestic production) with an annual capacity of 13 million tons after Steel Authority of India Ltd. (SAIL). TATA Steel, along with SAIL and Jindal Steel and Power, are the only 3 Indian steel companies that have captive iron-ore mines, which gives the three companies price advantages.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Advantage backward integration</u></b><br> Having its captive mines for the key raw-material, iron ore is the biggest advantage and helps the company manage through difficult times and expand margins when going gets good for steel prices as has been the cases for last few quarters.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Price rise - Some old and new tailwinds</u></b><br>The performance was expected to be better given the price increase which steel industry was able to manage during after lockdown opened and maintain as subsequent wave of covid hit global market. But will this sustain as global trade re-starts after omicron wave end in China along with possibility of US dollar gaining strength is something to look for. The only new tailwind for prices is the disruption due Russia-Ukraine as Russia has substantial steel capacity which would be out of circulation for some time </p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Advance indicator - Chinese demand</u></b><br>China is the largest producer and consumer of steel. Any dip in Chinese demand pushes the global steel prices down sharply. Chinese macro numbers, especially PMI are an advance indicators of what might happen to steel stocks globally including India.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>• <b><u>European restructuring holds second key</u></b><br>With rising steel prices, European operations which had been a pain point for long saw an improvement. But some challenges still remain in place. Once long over due restructuring of European is finally over, overall debt will come down and the help the case of continued re-rating..</p>",unsafe_allow_html=True)

    elif(result == "TCS"):
        st.image("images/tcs.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/feb82019-b51e-4d23-ac43-ecca55a4b47a/ReportSection"
        #st.image("images/tc stock.png",width=800)
        df=pd.read_csv('new_data_tcs.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("TCS STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'> Tata Consultancy Services (TCS) is an Indian multinational information technology (IT) services and consulting company with its headquarters in Mumbai. It is a part of the Tata Group and operates in 149 locations across 46 countries. In July 2022, it was reported that TCS had crossed 6 lakh or 600,000 Employees worldwide. </p>"

        "<p style = 'color : white ;margin-top:2.5rem; font-size : 1.3rem ;font-family: 'Crimson Text', serif; '> TCS is the second largest Indian Company by market capitalization and is among the most valuable IT service brands worldwide. In 2015, TCS was ranked 64th overall in the Forbes 'World's Most Innovative Companies ranking', making it one of the highest-ranked IT services companies and a top Indian company. As of 2018, it is ranked eleventh on the Fortune India 500 list. In April 2018, TCS became the first Indian IT company to reach $100 billion in market capitalization and the second Indian company ever (Reliance Industries achieved it in 2007) after its market capitalization stood at ₹6.793 trillion (equivalent to ₹7.7 trillion or US$97 billion in 2020) on the Bombay Stock Exchange.</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family:Hind;'>•	<b><u>Currency gains - Will they be back ?</u></b><br> With US fed changing its stance on interest rate. Will currency gains make a comeback at the same pace at they use to in past. If it happens stock out performance in relation to some of its peers might continue.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>FY 22 - Better on many counts</u></b><br>Manpower count - Of the total work force of 592,195 employees, 103,546 people or were added in in FY 22 only. Which means that close to 17.48 percent headcount is just one year old in the company. Clients - The company added 121 new clients in FY22, out which 10 were added in 100 million USD segment. Free cash flow - Rs 39,181 crore. Total amount spent on buy back and dividends in FY 22 - Rs 31,424 Cr</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>White House - No longer a factor ?</u></b><br>The pandemic which has made remote working a new normal partially takes care of the uncertainty every change in the White House used to bring in immigration policy and H1-B rules. It is very likely that over medium term the change in US administration becomes irrelevant for IT companies..</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;;'>•	<b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 17.01% outperformed its 3 year CAGR of 9.0%. (Source: Consolidated Financials).</p>",unsafe_allow_html=True)

    elif(result == "Tech Mahindra"):
        st.image("images/techmahindra.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/b40bda0f-9203-4b96-a366-594b93901b54/ReportSection"
        #st.image("images/techmahin stock.png",width=800)
        df=pd.read_csv('new_data_techm.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Tech Mahindra STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)
        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'> Tech Mahindra is an Indian multinational information technology services and consulting company. Part of the Mahindra Group, the company is headquartered in Pune and has its registered office in Mumbai. Tech Mahindra is a US$5.2 billion company with over 145,000 employees across 90 countries. The company was ranked #5 in India's IT firms and overall #47 on Fortune India 500 list for 2019. On 25 June 2013, Tech Mahindra announced the completion of a merger with Mahindra Satyam. Tech Mahindra has 973 active clients as of April 2020.  </p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Currency- Possible tailwinds</u></b><br> The current high liquidity in global markets meant that currency gains remain subdued for last six quarters, But with US fed tightening its money printing machine, probability of that currency might become a tailwinds are high.</p>"

        "<p style = 'color :white;font-size:1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 18.42% outperformed its 3 year CAGR of 8.96%. (Source: Consolidated Financials)</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Sell Signal: Bears on driving seat</u></b><br>50 day moving crossover appeared on Sep 01, 2022. Average price decline of -4.03% within 30 days of this signal in last 5 years.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Stock Returns vs Nifty 100</u></b><br>Stock gave a 3 year return of 49.95% as compared to Nifty 100 which gave a return of 62.37%. (as of last trading session)</p>",unsafe_allow_html=True)

    elif(result == "Trident"):
        st.image("images/trident.jpg",width=450)
        url = "https://app.powerbi.com/groups/me/reports/6050f335-c33b-4369-9e0a-13cf5b6e8656/ReportSection"
        #st.image("images/trident stock.png",width=800)
        df=pd.read_csv('new_data_trident.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Trident STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'> Trident Limited a part of USD 1 billion Trident Group is headquartered in Ludhiana Punjab. Established in the year 1990 the Company has evolved as a global textile player under the visionary leadership of its founder chairman Mr Rajinder Gupta a first generation entrepreneur. Trident Limited is a leading manufacturer of Yarn Bath Linen Bed Linen Wheat Straw-based Paper Chemicals and Captive Power. The Company has state-of-the-art manufacturing facilities in Barnala (Punjab) and Budni (Madhya Pradesh). The Company has a strong clientele in 100 countries across the globe. </p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Intraday fact check</u></b><br> In the last 17 years, only 5.28 % trading sessions saw intraday gains higher than 5 % .</p>"

         "<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>• ROE Outperforming 5 Year Average</u></b><br>Company delivered ROE of 21.68% in year ending 31 Mar, 2022 outperforming its 5 year avg. of 13.31%. (Source: Consolidated Financials).</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 54.4% outperformed its 3 year CAGR of 9.77%. (Source: Consolidated Financials).</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Buy Signal: Green flag for Bulls<br>Weekly stochastic crossover appeared on week ending Sep 02, 2022. Average price gain of 14.22% within 7 weeks of this signal in last 10 years.)</p>",unsafe_allow_html=True)

    elif(result == "UltraTech"):
        st.image("images/ultra.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/5bf84dad-32d7-49ff-b994-0dd4e7ab3d27/ReportSection"
        #st.image("images/ultratech stock.png",width=800)
        df=pd.read_csv('new_data_ultratech.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Ultra Tech STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)

        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'> UltraTech Cement Limited is an Indian cement company based in Mumbai, and a part of Aditya Birla Group. UltraTech is the largest manufacturer of grey cement, ready-mix concrete (RMC) and white cement in India with an installed capacity of 116.75 million tonnes per annum. It is the only company in the world to have a capacity of over 100 million tonnes in a single country, outside of China.  </p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Next trigger<</u></b>br> The company has been aiming to reduce its debt. Once this comes to a reasonable level, the addition to earnings is likely to improve sharply, though it takes a couple of quarters to reach that space</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Entry of new business house in cement sector</u></b><br>With two major cement companies on the block, there is probability that new business house would enter this extremely competitive sector. Will it change the competitive intensity for better or for worse needs to be seen. Given the that competition commission of India ( CCI ) keeps a close watch on this sector, probability of its turning for better is low.</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Costs under control - watch for diesel prices</u></b><br>The focus of the company has shifted to control fixed cost by improving efficiency at the plant-level. As a result, the expansion in margins took place in some quarters of FY 21 and also FY22. Though rising fuel cost might put some pressure in near term.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Public and private spending</u></b><br>Cement demand is linked to spending on infrastructure -- which is largely public expenditure -- and real estate, which is private sector-led demand. Public spending is still at higher level. The real estate demand, which on face it looks improved but has largely taken care of the inventory.</p>",unsafe_allow_html=True)

    elif(result == "Wipro"):
        st.image("images/wiprp.png",width=450)
        url = "https://app.powerbi.com/groups/me/reports/d3c6cc90-8717-444f-84de-916f47ed9551/ReportSection"
        #st.image("images/wipro stock.png",width=800)
        df=pd.read_csv('new_data_wipro.csv')
        plot=px.line(x='Date',y='Close',data_frame=df,title=("Wipro  STOCK PREDICTION"))
        #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Prediction'],
            name="Prediction"       # this sets its legend entry
            ))
        plot.update_layout(
            font_family="Times New Roman",
            font_color="blue",
            title_font_family="Times New Roman",
            title_font_color="red",
            legend_title_font_color="green"
            )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)
        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'>Wipro Limited (formerly, Western India Palm Refined Oils Limited) is an Indian multinational corporation that provides information technology, consulting and business process services. Thierry Delaporte is serving as CEO and managing director of Wipro from July 2020.[4] It is headquartered in Bangalore, Karnataka, India</p>"
        "<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family:'Crimson Text',serif;'>Wipro's capabilities range across cloud computing, cyber security, digital transformation, artificial intelligence, robotics, data analytics, and other technology consulting services to customers in 67 countries</p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Stock Returns vs Nifty 100</u></b><br> Stock gave a 3 year return of 60.73% as compared to Nifty 100 which gave a return of 62.37%. (as of last trading session)</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Currency winds - Will they turn favorable ?</u></b><br>Given the abundant liquidity in the global markets, there has been a little scope of any major currency gains. But, now with US fed slowing its money printing machine, will the currency tailwind make a come back needs to watched.</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Better sectoral mix in first three quarter of FY22</u></b><br>FY 21 saw company broad basing its sectoral revenue stream. If this trend continues, signs of which are visible in first three quarters of FY 22 also, it would help in company in insulating itself from any sudden slowdown in tech spending in a particular sector which is bound to come as this wave of higher tech spending gets plateaued</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 26.5% outperformed its 3 year CAGR of 9.6%. (Source: Consolidated Financials)</p>",unsafe_allow_html=True)

    elif(result=="IBN (ICICI)"):
        st.image("images/ibn(icici).png",width=450)
         
        url = "https://app.powerbi.com/groups/me/reports/809486f9-ec39-4b5b-8bf7-6607fdc266f6/ReportSection"
        #st.image("images/ibn stock.png",width=800)
        
        df=pd.read_csv('new_data_ibn.csv')
        
        plot=px.line(x='Date',y='Close',data_frame=df,title=("IBN (ICICI) STOCK PREDICTION"))
         #plot.add_scatter(x=df['Date'],y=df['Prediction'], mode='lines')
        plot.add_trace(go.Scatter(
             x=df['Date'],
             y=df['Prediction'],
             name="Prediction"       # this sets its legend entry
             ))
        plot.update_layout(
             font_family="Times New Roman",
             font_color="blue",
             title_font_family="Times New Roman",
             title_font_color="red",
             legend_title_font_color="green"
        )
        plot.show()
        st.write("### For Analysis Of This Stock [Click Here](%s)" % url)
        st.write("<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family: 'Crimson Text', serif;'> ICICI Bank Limited is an Indian multinational bank and financial services company headquartered in Vadodara. It offers a wide range of banking products and financial services for corporate and retail customers through a variety of delivery channels and specialized subsidiaries in the areas of investment banking, life, non-life insurance, venture capital and asset management. </p>"
        "<p style='color:white;margin-top:2.5rem;font-size:1.3rem;font-family:Hind;'> The bank has a network of 5,275 branches and 15,589 ATMs across India and has a presence in 17 countries. The bank has subsidiaries in the United Kingdom and Canada; branches in United States, Singapore, Bahrain, Hong Kong, Qatar, Oman, Dubai International Finance Centre, China and South Africa as well as representative offices in United Arab Emirates, Bangladesh, Malaysia and Indonesia. The company's UK subsidiary has also established branches in Belgium and Germany. </p>",unsafe_allow_html=True)

        st.write("<h2 style='color:yellow;'> Insights </h2>",unsafe_allow_html=True)
       
        st.write("<p style = 'color :white;font-size : 1.1rem ;font-family: 'Crimson Text', serif;'>•	<b><u>Currency- Possible tailwinds</u></b><br> The current high liquidity in global markets meant that currency gains remain subdued for last six quarters, But with US fed tightening its money printing machine, probability of that currency might become a tailwinds are high.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Beating 3 Yr Revenue CAGR</u></b><br>Company's annual revenue growth of 18.42% outperformed its 3 year CAGR of 8.96%. (Source: Consolidated Financials)</p>"

         "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'> •	<b><u>Sell Signal: Bears on driving seat</u></b><br>50 day moving crossover appeared on Sep 01, 2022. Average price decline of -4.03% within 30 days of this signal in last 5 years.</p>"

        "<p style = 'color :white;font-size : 1.1rem;font-family: 'Crimson Text', serif;'>•	<b><u>Stock Returns vs Nifty 100</u></b><br>Stock gave a 3 year return of 49.95% as compared to Nifty 100 which gave a return of 62.37%. (as of last trading session)</p>",unsafe_allow_html=True)